import React, { useState } from 'react';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  BarElement,
} from 'chart.js';
import './Employee.css';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  BarElement
);

// Initial data
const initialData = {
  inventory: [
    {
      itemId: 1,
      itemName: "Laptop Dell XPS 13",
      category: "Electronics",
      quantity: 25,
      location: "Zone A-1",
      lastUpdated: "2025-08-20T10:30:00Z"
    },
    {
      itemId: 2,
      itemName: "Office Chair Ergonomic",
      category: "Furniture",
      quantity: 50,
      location: "Zone B-2",
      lastUpdated: "2025-08-19T14:20:00Z"
    },
    {
      itemId: 3,
      itemName: "Wireless Mouse",
      category: "Electronics",
      quantity: 150,
      location: "Zone A-3",
      lastUpdated: "2025-08-21T09:15:00Z"
    },
    {
      itemId: 4,
      itemName: "Steel Filing Cabinet",
      category: "Furniture",
      quantity: 8,
      location: "Zone C-1",
      lastUpdated: "2025-08-18T16:45:00Z"
    },
    {
      itemId: 5,
      itemName: "Printer HP LaserJet",
      category: "Electronics",
      quantity: 12,
      location: "Zone A-2",
      lastUpdated: "2025-08-22T11:30:00Z"
    }
  ],
  spaces: [
    {
      spaceId: 1,
      zone: "Zone A",
      totalCapacity: 1000,
      usedCapacity: 750,
      availableCapacity: 250
    },
    {
      spaceId: 2,
      zone: "Zone B",
      totalCapacity: 800,
      usedCapacity: 600,
      availableCapacity: 200
    },
    {
      spaceId: 3,
      zone: "Zone C",
      totalCapacity: 500,
      usedCapacity: 300,
      availableCapacity: 200
    },
    {
      spaceId: 4,
      zone: "Zone D",
      totalCapacity: 1200,
      usedCapacity: 900,
      availableCapacity: 300
    }
  ],
  shipments: [
    {
      shipmentId: 1,
      itemId: 1,
      origin: "Supplier A",
      destination: "Customer B",
      status: "Transit",
      expectedDeliveryDate: "2025-08-28T00:00:00Z"
    },
    {
      shipmentId: 2,
      itemId: 3,
      origin: "Warehouse Main",
      destination: "Branch Office",
      status: "Delivered",
      expectedDeliveryDate: "2025-08-25T00:00:00Z"
    },
    {
      shipmentId: 3,
      itemId: 2,
      origin: "Manufacturing Unit",
      destination: "Warehouse Main",
      status: "Pending",
      expectedDeliveryDate: "2025-08-30T00:00:00Z"
    }
  ],
  maintenance: [
    {
      maintenanceId: 1,
      equipmentId: "EQ001",
      equipmentName: "Forklift",
      type: "Preventive",
      scheduledDate: "2025-08-25T00:00:00Z",
      status: "Scheduled",
      technician: "John Smith"
    },
    {
      maintenanceId: 2,
      equipmentId: "EQ002",
      equipmentName: "Conveyor Belt",
      type: "Corrective",
      scheduledDate: "2025-08-22T00:00:00Z",
      status: "Progress",
      technician: "Sarah Johnson"
    }
  ]
};

function Employee() {
  const [data, setData] = useState(initialData);
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [sidebarVisible, setSidebarVisible] = useState(true);

  // Navigation items
  const navigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fas fa-tachometer-alt' },
    { id: 'inventory', label: 'Inventory Management', icon: 'fas fa-boxes' },
    { id: 'space', label: 'Space Optimization', icon: 'fas fa-warehouse' },
    { id: 'shipments', label: 'Shipment Handling', icon: 'fas fa-truck' },
    { id: 'maintenance', label: 'Maintenance Scheduling', icon: 'fas fa-wrench' },
    { id: 'reports', label: 'Performance Reporting', icon: 'fas fa-chart-bar' }
  ];

  const handleUpdateData = (newData) => {
    setData(newData);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard data={data} />;
      case 'inventory':
        return <InventoryManagement data={data} onUpdateData={handleUpdateData} />;
      case 'space':
        return <SpaceOptimization data={data} onUpdateData={handleUpdateData} />;
      case 'shipments':
        return <ShipmentHandling data={data} onUpdateData={handleUpdateData} />;
      case 'maintenance':
        return <MaintenanceScheduling data={data} onUpdateData={handleUpdateData} />;
      case 'reports':
        return <PerformanceReporting data={data} />;
      default:
        return <Dashboard data={data} />;
    }
  };

  return (
    <div className="app">
      <button 
        className="mobile-menu-btn"
        onClick={() => setSidebarVisible(!sidebarVisible)}
      >
        <i className="fas fa-bars"></i>
      </button>

      <aside className={`sidebar ${!sidebarVisible ? 'sidebar-hidden' : ''}`}>
        <div className="sidebar__logo">
          <i className="fas fa-warehouse"></i>
          <h1>LWMS</h1>
        </div>
        <nav className="sidebar__nav">
          <ul>
            {navigationItems.map(item => (
              <li key={item.id} className="sidebar__nav-item">
                <a
                  href="#"
                  className={`sidebar__nav-link ${currentPage === item.id ? 'active' : ''}`}
                  onClick={(e) => {
                    e.preventDefault();
                    setCurrentPage(item.id);
                  }}
                >
                  <i className={item.icon}></i>
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      <main className={`main-content ${!sidebarVisible ? 'sidebar-hidden' : ''}`}>
        {renderCurrentPage()}
      </main>
    </div>
  );
}

// Dashboard Component
function Dashboard({ data }) {
  const totalInventory = data.inventory.reduce((sum, item) => sum + item.quantity, 0);
  const activeShipments = data.shipments.filter(s => s.status === 'Transit').length;
  const pendingMaintenance = data.maintenance.filter(m => m.status === 'Scheduled').length;

  return (
    <div className="dashboard">
      <div className="page-header">
        <h1>Dashboard</h1>
      </div>

      <div className="dashboard__metrics">
        <div className="metric-card">
          <div className="metric-card__icon metric-card__icon--primary">
            <i className="fas fa-boxes"></i>
          </div>
          <div className="metric-card__content">
            <h3>Total Inventory</h3>
            <p className="metric-card__value">{totalInventory.toLocaleString()}</p>
            <p className="metric-card__change">Current stock levels</p>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-card__icon metric-card__icon--success">
            <i className="fas fa-truck"></i>
          </div>
          <div className="metric-card__content">
            <h3>Active Shipments</h3>
            <p className="metric-card__value">{activeShipments}</p>
            <p className="metric-card__change">Currently in transit</p>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-card__icon metric-card__icon--warning">
            <i className="fas fa-warehouse"></i>
          </div>
          <div className="metric-card__content">
            <h3>Storage Zones</h3>
            <p className="metric-card__value">{data.spaces.length}</p>
            <p className="metric-card__change">Active zones</p>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-card__icon metric-card__icon--info">
            <i className="fas fa-wrench"></i>
          </div>
          <div className="metric-card__content">
            <h3>Pending Maintenance</h3>
            <p className="metric-card__value">{pendingMaintenance}</p>
            <p className="metric-card__change">Scheduled tasks</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// Inventory Management Component
function InventoryManagement({ data, onUpdateData }) {
  const [editingItem, setEditingItem] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newItem, setNewItem] = useState({
    itemName: '',
    category: '',
    quantity: '',
    location: ''
  });

  const handleEdit = (item) => {
    setEditingItem({ ...item });
  };

  const handleSave = () => {
    if (editingItem) {
      const updatedInventory = data.inventory.map(item =>
        item.itemId === editingItem.itemId ? editingItem : item
      );
      onUpdateData({ ...data, inventory: updatedInventory });
      setEditingItem(null);
    }
  };

  const handleAdd = () => {
    if (newItem.itemName && newItem.category && newItem.quantity && newItem.location) {
      const newInventoryItem = {
        itemId: Math.max(...data.inventory.map(item => item.itemId)) + 1,
        itemName: newItem.itemName,
        category: newItem.category,
        quantity: parseInt(newItem.quantity),
        location: newItem.location,
        lastUpdated: new Date().toISOString()
      };
      
      const updatedInventory = [...data.inventory, newInventoryItem];
      onUpdateData({ ...data, inventory: updatedInventory });
      
      setNewItem({ itemName: '', category: '', quantity: '', location: '' });
      setShowAddForm(false);
    }
  };

  const handleDelete = (itemId) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      const updatedInventory = data.inventory.filter(item => item.itemId !== itemId);
      onUpdateData({ ...data, inventory: updatedInventory });
    }
  };

  return (
    <div className="inventory-management">
      <div className="page-header">
        <h1>Inventory Management</h1>
        <button 
          className="btn btn--primary"
          onClick={() => setShowAddForm(!showAddForm)}
        >
          <i className="fas fa-plus"></i> Add New Item
        </button>
      </div>

      {showAddForm && (
        <div className="add-form">
          <h3>Add New Item</h3>
          <div className="form-row">
            <div className="form-group">
              <label>Item Name</label>
              <input
                type="text"
                value={newItem.itemName}
                onChange={(e) => setNewItem({ ...newItem, itemName: e.target.value })}
                placeholder="Enter item name"
              />
            </div>
            <div className="form-group">
              <label>Category</label>
              <select
                value={newItem.category}
                onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
              >
                <option value="">Select category</option>
                <option value="Electronics">Electronics</option>
                <option value="Furniture">Furniture</option>
                <option value="Office Supplies">Office Supplies</option>
                <option value="Tools">Tools</option>
              </select>
            </div>
            <div className="form-group">
              <label>Quantity</label>
              <input
                type="number"
                value={newItem.quantity}
                onChange={(e) => setNewItem({ ...newItem, quantity: e.target.value })}
                placeholder="Enter quantity"
              />
            </div>
            <div className="form-group">
              <label>Location</label>
              <input
                type="text"
                value={newItem.location}
                onChange={(e) => setNewItem({ ...newItem, location: e.target.value })}
                placeholder="Enter location"
              />
            </div>
          </div>
          <div className="form-actions">
            <button className="btn btn--primary" onClick={handleAdd}>
              Add Item
            </button>
            <button className="btn btn--secondary" onClick={() => setShowAddForm(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="inventory-table">
        <table>
          <thead>
            <tr>
              <th>Item ID</th>
              <th>Item Name</th>
              <th>Category</th>
              <th>Quantity</th>
              <th>Location</th>
              <th>Last Updated</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.inventory.map(item => (
              <tr key={item.itemId}>
                <td>{item.itemId}</td>
                <td>
                  {editingItem?.itemId === item.itemId ? (
                    <input
                      type="text"
                      value={editingItem.itemName}
                      onChange={(e) => setEditingItem({ ...editingItem, itemName: e.target.value })}
                    />
                  ) : (
                    item.itemName
                  )}
                </td>
                <td>
                  {editingItem?.itemId === item.itemId ? (
                    <select
                      value={editingItem.category}
                      onChange={(e) => setEditingItem({ ...editingItem, category: e.target.value })}
                    >
                      <option value="Electronics">Electronics</option>
                      <option value="Furniture">Furniture</option>
                      <option value="Office Supplies">Office Supplies</option>
                      <option value="Tools">Tools</option>
                    </select>
                  ) : (
                    item.category
                  )}
                </td>
                <td>
                  {editingItem?.itemId === item.itemId ? (
                    <input
                      type="number"
                      value={editingItem.quantity}
                      onChange={(e) => setEditingItem({ ...editingItem, quantity: parseInt(e.target.value) })}
                    />
                  ) : (
                    item.quantity
                  )}
                </td>
                <td>
                  {editingItem?.itemId === item.itemId ? (
                    <input
                      type="text"
                      value={editingItem.location}
                      onChange={(e) => setEditingItem({ ...editingItem, location: e.target.value })}
                    />
                  ) : (
                    item.location
                  )}
                </td>
                <td>{new Date(item.lastUpdated).toLocaleDateString()}</td>
                <td>
                  {editingItem?.itemId === item.itemId ? (
                    <div className="action-buttons">
                      <button className="btn btn--success btn--small" onClick={handleSave}>
                        Save
                      </button>
                      <button 
                        className="btn btn--secondary btn--small" 
                        onClick={() => setEditingItem(null)}
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <div className="action-buttons">
                      <button 
                        className="btn btn--primary btn--small" 
                        onClick={() => handleEdit(item)}
                      >
                        Edit
                      </button>
                      <button 
                        className="btn btn--danger btn--small" 
                        onClick={() => handleDelete(item.itemId)}
                      >
                        Delete
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Space Optimization Component
function SpaceOptimization({ data, onUpdateData }) {
  const [editingSpace, setEditingSpace] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newSpace, setNewSpace] = useState({
    zone: '',
    totalCapacity: '',
    usedCapacity: ''
  });

  const handleEdit = (space) => {
    setEditingSpace({ ...space });
  };

  const handleSave = () => {
    if (editingSpace) {
      const updatedSpace = {
        ...editingSpace,
        availableCapacity: editingSpace.totalCapacity - editingSpace.usedCapacity
      };
      
      const updatedSpaces = data.spaces.map(space =>
        space.spaceId === updatedSpace.spaceId ? updatedSpace : space
      );
      onUpdateData({ ...data, spaces: updatedSpaces });
      setEditingSpace(null);
    }
  };

  const handleAdd = () => {
    if (newSpace.zone && newSpace.totalCapacity && newSpace.usedCapacity) {
      const newSpaceItem = {
        spaceId: Math.max(...data.spaces.map(space => space.spaceId)) + 1,
        zone: newSpace.zone,
        totalCapacity: parseInt(newSpace.totalCapacity),
        usedCapacity: parseInt(newSpace.usedCapacity),
        availableCapacity: parseInt(newSpace.totalCapacity) - parseInt(newSpace.usedCapacity)
      };
      
      const updatedSpaces = [...data.spaces, newSpaceItem];
      onUpdateData({ ...data, spaces: updatedSpaces });
      
      setNewSpace({ zone: '', totalCapacity: '', usedCapacity: '' });
      setShowAddForm(false);
    }
  };

  const handleDelete = (spaceId) => {
    if (window.confirm('Are you sure you want to delete this space?')) {
      const updatedSpaces = data.spaces.filter(space => space.spaceId !== spaceId);
      onUpdateData({ ...data, spaces: updatedSpaces });
    }
  };

  return (
    <div className="space-optimization">
      <div className="page-header">
        <h1>Space Optimization</h1>
        <button 
          className="btn btn--primary"
          onClick={() => setShowAddForm(!showAddForm)}
        >
          <i className="fas fa-plus"></i> Add New Zone
        </button>
      </div>

      {showAddForm && (
        <div className="add-form">
          <h3>Add New Zone</h3>
          <div className="form-row">
            <div className="form-group">
              <label>Zone Name</label>
              <input
                type="text"
                value={newSpace.zone}
                onChange={(e) => setNewSpace({ ...newSpace, zone: e.target.value })}
                placeholder="Enter zone name"
              />
            </div>
            <div className="form-group">
              <label>Total Capacity</label>
              <input
                type="number"
                value={newSpace.totalCapacity}
                onChange={(e) => setNewSpace({ ...newSpace, totalCapacity: e.target.value })}
                placeholder="Enter total capacity"
              />
            </div>
            <div className="form-group">
              <label>Used Capacity</label>
              <input
                type="number"
                value={newSpace.usedCapacity}
                onChange={(e) => setNewSpace({ ...newSpace, usedCapacity: e.target.value })}
                placeholder="Enter used capacity"
              />
            </div>
          </div>
          <div className="form-actions">
            <button className="btn btn--primary" onClick={handleAdd}>
              Add Zone
            </button>
            <button className="btn btn--secondary" onClick={() => setShowAddForm(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="spaces-grid">
        {data.spaces.map(space => (
          <div key={space.spaceId} className="space-card">
            <div className="space-card__header">
              <h3>{space.zone}</h3>
              <div className="space-card__actions">
                {editingSpace?.spaceId === space.spaceId ? (
                  <>
                    <button className="btn btn--success btn--small" onClick={handleSave}>
                      Save
                    </button>
                    <button 
                      className="btn btn--secondary btn--small" 
                      onClick={() => setEditingSpace(null)}
                    >
                      Cancel
                    </button>
                  </>
                ) : (
                  <>
                    <button 
                      className="btn btn--primary btn--small" 
                      onClick={() => handleEdit(space)}
                    >
                      Edit
                    </button>
                    <button 
                      className="btn btn--danger btn--small" 
                      onClick={() => handleDelete(space.spaceId)}
                    >
                      Delete
                    </button>
                  </>
                )}
              </div>
            </div>
            
            <div className="space-card__content">
              <div className="capacity-info">
                <div className="capacity-item">
                  <span className="capacity-label">Total:</span>
                  <span className="capacity-value">
                    {editingSpace?.spaceId === space.spaceId ? (
                      <input
                        type="number"
                        value={editingSpace.totalCapacity}
                        onChange={(e) => setEditingSpace({ 
                          ...editingSpace, 
                          totalCapacity: parseInt(e.target.value) 
                        })}
                      />
                    ) : (
                      space.totalCapacity.toLocaleString()
                    )}
                  </span>
                </div>
                
                <div className="capacity-item">
                  <span className="capacity-label">Used:</span>
                  <span className="capacity-value">
                    {editingSpace?.spaceId === space.spaceId ? (
                      <input
                        type="number"
                        value={editingSpace.usedCapacity}
                        onChange={(e) => setEditingSpace({ 
                          ...editingSpace, 
                          usedCapacity: parseInt(e.target.value) 
                        })}
                      />
                    ) : (
                      space.usedCapacity.toLocaleString()
                    )}
                  </span>
                </div>
                
                <div className="capacity-item">
                  <span className="capacity-label">Available:</span>
                  <span className="capacity-value">
                    {space.availableCapacity.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Shipment Handling Component
function ShipmentHandling({ data, onUpdateData }) {
  const [editingShipment, setEditingShipment] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newShipment, setNewShipment] = useState({
    itemId: '',
    origin: '',
    destination: '',
    status: 'Pending',
    expectedDeliveryDate: ''
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'Delivered': return 'success';
      case 'Transit': return 'warning';
      case 'Pending': return 'info';
      default: return 'secondary';
    }
  };

  const handleEdit = (shipment) => {
    setEditingShipment({ ...shipment });
  };

  const handleSave = () => {
    if (editingShipment) {
      const updatedShipments = data.shipments.map(shipment =>
        shipment.shipmentId === editingShipment.shipmentId ? editingShipment : shipment
      );
      onUpdateData({ ...data, shipments: updatedShipments });
      setEditingShipment(null);
    }
  };

  const handleAdd = () => {
    if (newShipment.itemId && newShipment.origin && newShipment.destination && newShipment.expectedDeliveryDate) {
      const newShipmentItem = {
        shipmentId: Math.max(...data.shipments.map(s => s.shipmentId)) + 1,
        itemId: parseInt(newShipment.itemId),
        origin: newShipment.origin,
        destination: newShipment.destination,
        status: newShipment.status,
        expectedDeliveryDate: new Date(newShipment.expectedDeliveryDate).toISOString()
      };
      
      const updatedShipments = [...data.shipments, newShipmentItem];
      onUpdateData({ ...data, shipments: updatedShipments });
      
      setNewShipment({ itemId: '', origin: '', destination: '', status: 'Pending', expectedDeliveryDate: '' });
      setShowAddForm(false);
    }
  };

  const handleDelete = (shipmentId) => {
    if (window.confirm('Are you sure you want to delete this shipment?')) {
      const updatedShipments = data.shipments.filter(s => s.shipmentId !== shipmentId);
      onUpdateData({ ...data, shipments: updatedShipments });
    }
  };

  return (
    <div className="shipment-handling">
      <div className="page-header">
        <h1>Shipment Handling</h1>
        <button 
          className="btn btn--primary"
          onClick={() => setShowAddForm(!showAddForm)}
        >
          <i className="fas fa-plus"></i> Add New Shipment
        </button>
      </div>

      {showAddForm && (
        <div className="add-form">
          <h3>Add New Shipment</h3>
          <div className="form-row">
            <div className="form-group">
              <label>Item ID</label>
              <select
                value={newShipment.itemId}
                onChange={(e) => setNewShipment({ ...newShipment, itemId: e.target.value })}
              >
                <option value="">Select item</option>
                {data.inventory.map(item => (
                  <option key={item.itemId} value={item.itemId}>
                    {item.itemId} - {item.itemName}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Origin</label>
              <input
                type="text"
                value={newShipment.origin}
                onChange={(e) => setNewShipment({ ...newShipment, origin: e.target.value })}
                placeholder="Enter origin"
              />
            </div>
            <div className="form-group">
              <label>Destination</label>
              <input
                type="text"
                value={newShipment.destination}
                onChange={(e) => setNewShipment({ ...newShipment, destination: e.target.value })}
                placeholder="Enter destination"
              />
            </div>
            <div className="form-group">
              <label>Status</label>
              <select
                value={newShipment.status}
                onChange={(e) => setNewShipment({ ...newShipment, status: e.target.value })}
              >
                <option value="Pending">Pending</option>
                <option value="Transit">Transit</option>
                <option value="Delivered">Delivered</option>
              </select>
            </div>
            <div className="form-group">
              <label>Expected Delivery Date</label>
              <input
                type="date"
                value={newShipment.expectedDeliveryDate}
                onChange={(e) => setNewShipment({ ...newShipment, expectedDeliveryDate: e.target.value })}
              />
            </div>
          </div>
          <div className="form-actions">
            <button className="btn btn--primary" onClick={handleAdd}>
              Add Shipment
            </button>
            <button className="btn btn--secondary" onClick={() => setShowAddForm(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="shipments-table">
        <table>
          <thead>
            <tr>
              <th>Shipment ID</th>
              <th>Item ID</th>
              <th>Origin</th>
              <th>Destination</th>
              <th>Status</th>
              <th>Expected Delivery</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.shipments.map(shipment => (
              <tr key={shipment.shipmentId}>
                <td>{shipment.shipmentId}</td>
                <td>{shipment.itemId}</td>
                <td>
                  {editingShipment?.shipmentId === shipment.shipmentId ? (
                    <input
                      type="text"
                      value={editingShipment.origin}
                      onChange={(e) => setEditingShipment({ ...editingShipment, origin: e.target.value })}
                    />
                  ) : (
                    shipment.origin
                  )}
                </td>
                <td>
                  {editingShipment?.shipmentId === shipment.shipmentId ? (
                    <input
                      type="text"
                      value={editingShipment.destination}
                      onChange={(e) => setEditingShipment({ ...editingShipment, destination: e.target.value })}
                    />
                  ) : (
                    shipment.destination
                  )}
                </td>
                <td>
                  {editingShipment?.shipmentId === shipment.shipmentId ? (
                    <select
                      value={editingShipment.status}
                      onChange={(e) => setEditingShipment({ ...editingShipment, status: e.target.value })}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Transit">Transit</option>
                      <option value="Delivered">Delivered</option>
                    </select>
                  ) : (
                    <span className={`status-badge status-badge--${getStatusColor(shipment.status)}`}>
                      {shipment.status}
                    </span>
                  )}
                </td>
                <td>
                  {editingShipment?.shipmentId === shipment.shipmentId ? (
                    <input
                      type="date"
                      value={editingShipment.expectedDeliveryDate.split('T')[0]}
                      onChange={(e) => setEditingShipment({ 
                        ...editingShipment, 
                        expectedDeliveryDate: new Date(e.target.value).toISOString() 
                      })}
                    />
                  ) : (
                    new Date(shipment.expectedDeliveryDate).toLocaleDateString()
                  )}
                </td>
                <td>
                  {editingShipment?.shipmentId === shipment.shipmentId ? (
                    <div className="action-buttons">
                      <button className="btn btn--success btn--small" onClick={handleSave}>
                        Save
                      </button>
                      <button 
                        className="btn btn--secondary btn--small" 
                        onClick={() => setEditingShipment(null)}
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <div className="action-buttons">
                      <button 
                        className="btn btn--primary btn--small" 
                        onClick={() => handleEdit(shipment)}
                      >
                        Edit
                      </button>
                      <button 
                        className="btn btn--danger btn--small" 
                        onClick={() => handleDelete(shipment.shipmentId)}
                      >
                        Delete
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Maintenance Scheduling Component
function MaintenanceScheduling({ data, onUpdateData }) {
  const [editingMaintenance, setEditingMaintenance] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newMaintenance, setNewMaintenance] = useState({
    equipmentId: '',
    equipmentName: '',
    type: 'Preventive',
    scheduledDate: '',
    status: 'Scheduled',
    technician: ''
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'Completed': return 'success';
      case 'Progress': return 'warning';
      case 'Scheduled': return 'info';
      case 'Overdue': return 'danger';
      default: return 'secondary';
    }
  };

  const handleEdit = (maintenance) => {
    setEditingMaintenance({ ...maintenance });
  };

  const handleSave = () => {
    if (editingMaintenance) {
      const updatedMaintenance = data.maintenance.map(m =>
        m.maintenanceId === editingMaintenance.maintenanceId ? editingMaintenance : m
      );
      onUpdateData({ ...data, maintenance: updatedMaintenance });
      setEditingMaintenance(null);
    }
  };

  const handleAdd = () => {
    if (newMaintenance.equipmentId && newMaintenance.equipmentName && newMaintenance.scheduledDate && newMaintenance.technician) {
      const newMaintenanceItem = {
        maintenanceId: Math.max(...data.maintenance.map(m => m.maintenanceId)) + 1,
        equipmentId: newMaintenance.equipmentId,
        equipmentName: newMaintenance.equipmentName,
        type: newMaintenance.type,
        scheduledDate: new Date(newMaintenance.scheduledDate).toISOString(),
        status: newMaintenance.status,
        technician: newMaintenance.technician
      };
      
      const updatedMaintenance = [...data.maintenance, newMaintenanceItem];
      onUpdateData({ ...data, maintenance: updatedMaintenance });
      
      setNewMaintenance({ 
        equipmentId: '', 
        equipmentName: '', 
        type: 'Preventive', 
        scheduledDate: '', 
        status: 'Scheduled', 
        technician: '' 
      });
      setShowAddForm(false);
    }
  };

  const handleDelete = (maintenanceId) => {
    if (window.confirm('Are you sure you want to delete this maintenance record?')) {
      const updatedMaintenance = data.maintenance.filter(m => m.maintenanceId !== maintenanceId);
      onUpdateData({ ...data, maintenance: updatedMaintenance });
    }
  };

  return (
    <div className="maintenance-scheduling">
      <div className="page-header">
        <h1>Maintenance Scheduling</h1>
        <button 
          className="btn btn--primary"
          onClick={() => setShowAddForm(!showAddForm)}
        >
          <i className="fas fa-plus"></i> Add New Maintenance
        </button>
      </div>

      {showAddForm && (
        <div className="add-form">
          <h3>Add New Maintenance</h3>
          <div className="form-row">
            <div className="form-group">
              <label>Equipment ID</label>
              <input
                type="text"
                value={newMaintenance.equipmentId}
                onChange={(e) => setNewMaintenance({ ...newMaintenance, equipmentId: e.target.value })}
                placeholder="Enter equipment ID"
              />
            </div>
            <div className="form-group">
              <label>Equipment Name</label>
              <input
                type="text"
                value={newMaintenance.equipmentName}
                onChange={(e) => setNewMaintenance({ ...newMaintenance, equipmentName: e.target.value })}
                placeholder="Enter equipment name"
              />
            </div>
            <div className="form-group">
              <label>Type</label>
              <select
                value={newMaintenance.type}
                onChange={(e) => setNewMaintenance({ ...newMaintenance, type: e.target.value })}
              >
                <option value="Preventive">Preventive</option>
                <option value="Corrective">Corrective</option>
                <option value="Emergency">Emergency</option>
              </select>
            </div>
            <div className="form-group">
              <label>Status</label>
              <select
                value={newMaintenance.status}
                onChange={(e) => setNewMaintenance({ ...newMaintenance, status: e.target.value })}
              >
                <option value="Scheduled">Scheduled</option>
                <option value="Progress">Progress</option>
                <option value="Completed">Completed</option>
                <option value="Overdue">Overdue</option>
              </select>
            </div>
            <div className="form-group">
              <label>Scheduled Date</label>
              <input
                type="date"
                value={newMaintenance.scheduledDate}
                onChange={(e) => setNewMaintenance({ ...newMaintenance, scheduledDate: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label>Technician</label>
              <input
                type="text"
                value={newMaintenance.technician}
                onChange={(e) => setNewMaintenance({ ...newMaintenance, technician: e.target.value })}
                placeholder="Enter technician name"
              />
            </div>
          </div>
          <div className="form-actions">
            <button className="btn btn--primary" onClick={handleAdd}>
              Add Maintenance
            </button>
            <button className="btn btn--secondary" onClick={() => setShowAddForm(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="maintenance-table">
        <table>
          <thead>
            <tr>
              <th>Maintenance ID</th>
              <th>Equipment ID</th>
              <th>Equipment Name</th>
              <th>Type</th>
              <th>Status</th>
              <th>Scheduled Date</th>
              <th>Technician</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.maintenance.map(maintenance => (
              <tr key={maintenance.maintenanceId}>
                <td>{maintenance.maintenanceId}</td>
                <td>{maintenance.equipmentId}</td>
                <td>
                  {editingMaintenance?.maintenanceId === maintenance.maintenanceId ? (
                    <input
                      type="text"
                      value={editingMaintenance.equipmentName}
                      onChange={(e) => setEditingMaintenance({ ...editingMaintenance, equipmentName: e.target.value })}
                    />
                  ) : (
                    maintenance.equipmentName
                  )}
                </td>
                <td>
                  {editingMaintenance?.maintenanceId === maintenance.maintenanceId ? (
                    <select
                      value={editingMaintenance.type}
                      onChange={(e) => setEditingMaintenance({ ...editingMaintenance, type: e.target.value })}
                    >
                      <option value="Preventive">Preventive</option>
                      <option value="Corrective">Corrective</option>
                      <option value="Emergency">Emergency</option>
                    </select>
                  ) : (
                    maintenance.type
                  )}
                </td>
                <td>
                  {editingMaintenance?.maintenanceId === maintenance.maintenanceId ? (
                    <select
                      value={editingMaintenance.status}
                      onChange={(e) => setEditingMaintenance({ ...editingMaintenance, status: e.target.value })}
                    >
                      <option value="Scheduled">Scheduled</option>
                      <option value="Progress">Progress</option>
                      <option value="Completed">Completed</option>
                      <option value="Overdue">Overdue</option>
                    </select>
                  ) : (
                    <span className={`status-badge status-badge--${getStatusColor(maintenance.status)}`}>
                      {maintenance.status}
                    </span>
                  )}
                </td>
                <td>
                  {editingMaintenance?.maintenanceId === maintenance.maintenanceId ? (
                    <input
                      type="date"
                      value={editingMaintenance.scheduledDate.split('T')[0]}
                      onChange={(e) => setEditingMaintenance({ 
                        ...editingMaintenance, 
                        scheduledDate: new Date(e.target.value).toISOString() 
                      })}
                    />
                  ) : (
                    new Date(maintenance.scheduledDate).toLocaleDateString()
                  )}
                </td>
                <td>
                  {editingMaintenance?.maintenanceId === maintenance.maintenanceId ? (
                    <input
                      type="text"
                      value={editingMaintenance.technician}
                      onChange={(e) => setEditingMaintenance({ ...editingMaintenance, technician: e.target.value })}
                    />
                  ) : (
                    maintenance.technician
                  )}
                </td>
                <td>
                  {editingMaintenance?.maintenanceId === maintenance.maintenanceId ? (
                    <div className="action-buttons">
                      <button className="btn btn--success btn--small" onClick={handleSave}>
                        Save
                      </button>
                      <button 
                        className="btn btn--secondary btn--small" 
                        onClick={() => setEditingMaintenance(null)}
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <div className="action-buttons">
                      <button 
                        className="btn btn--primary btn--small" 
                        onClick={() => handleEdit(maintenance)}
                      >
                        Edit
                      </button>
                      <button 
                        className="btn btn--danger btn--small" 
                        onClick={() => handleDelete(maintenance.maintenanceId)}
                      >
                        Delete
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Performance Reporting Component
function PerformanceReporting({ data }) {
  const [selectedReport, setSelectedReport] = useState('overview');
  const [dateRange, setDateRange] = useState('week');

  // Calculate performance metrics
  const totalInventory = data.inventory.reduce((sum, item) => sum + item.quantity, 0);
  const totalSpaces = data.spaces.length;
  const totalShipments = data.shipments.length;
  const completedShipments = data.shipments.filter(s => s.status === 'Delivered').length;
  const deliveryRate = totalShipments > 0 ? ((completedShipments / totalShipments) * 100).toFixed(1) : 0;
  const totalMaintenance = data.maintenance.length;
  const completedMaintenance = data.maintenance.filter(m => m.status === 'Completed').length;
  const maintenanceRate = totalMaintenance > 0 ? ((completedMaintenance / totalMaintenance) * 100).toFixed(1) : 0;

  // Chart data
  const spaceUtilizationData = {
    labels: data.spaces.map(space => space.zone),
    datasets: [{
      label: 'Used Capacity',
      data: data.spaces.map(space => space.usedCapacity),
      backgroundColor: 'rgba(102, 126, 234, 0.8)',
      borderColor: 'rgba(102, 126, 234, 1)',
      borderWidth: 1
    }]
  };

  const shipmentStatusData = {
    labels: ['Delivered', 'Transit', 'Pending'],
    datasets: [{
      data: [
        data.shipments.filter(s => s.status === 'Delivered').length,
        data.shipments.filter(s => s.status === 'Transit').length,
        data.shipments.filter(s => s.status === 'Pending').length
      ],
      backgroundColor: [
        'rgba(40, 167, 69, 0.8)',
        'rgba(255, 193, 7, 0.8)',
        'rgba(23, 162, 184, 0.8)'
      ],
      borderColor: [
        'rgba(40, 167, 69, 1)',
        'rgba(255, 193, 7, 1)',
        'rgba(23, 162, 184, 1)'
      ],
      borderWidth: 1
    }]
  };

  const maintenanceStatusData = {
    labels: ['Completed', 'Progress', 'Scheduled', 'Overdue'],
    datasets: [{
      data: [
        data.maintenance.filter(m => m.status === 'Completed').length,
        data.maintenance.filter(m => m.status === 'Progress').length,
        data.maintenance.filter(m => m.status === 'Scheduled').length,
        data.maintenance.filter(m => m.status === 'Overdue').length
      ],
      backgroundColor: [
        'rgba(40, 167, 69, 0.8)',
        'rgba(255, 193, 7, 0.8)',
        'rgba(23, 162, 184, 0.8)',
        'rgba(220, 53, 69, 0.8)'
      ],
      borderColor: [
        'rgba(40, 167, 69, 1)',
        'rgba(255, 193, 7, 1)',
        'rgba(23, 162, 184, 1)',
        'rgba(220, 53, 69, 1)'
      ],
      borderWidth: 1
    }]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom'
      }
    }
  };

  const getReportTitle = () => {
    switch (selectedReport) {
      case 'overview': return 'Overall Performance Overview';
      case 'shipments': return 'Shipment Performance Analysis';
      case 'maintenance': return 'Maintenance Performance Analysis';
      default: return 'Overall Performance Overview';
    }
  };

  return (
    <div className="performance-reporting">
      <div className="page-header">
        <h1>Performance Reporting</h1>
      </div>

      <div className="performance-metrics">
        <div className="metric-card">
          <div className="metric-card__icon metric-card__icon--primary">
            <i className="fas fa-warehouse"></i>
          </div>
          <div className="metric-card__content">
            <h3>Space Utilization</h3>
            <p className="metric-card__value">{totalSpaces}</p>
            <p className="metric-card__change">Active storage zones</p>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-card__icon metric-card__icon--success">
            <i className="fas fa-truck"></i>
          </div>
          <div className="metric-card__content">
            <h3>Delivery Rate</h3>
            <p className="metric-card__value">{deliveryRate}%</p>
            <p className="metric-card__change">Successful deliveries</p>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-card__icon metric-card__icon--info">
            <i className="fas fa-wrench"></i>
          </div>
          <div className="metric-card__content">
            <h3>Maintenance Rate</h3>
            <p className="metric-card__value">{maintenanceRate}%</p>
            <p className="metric-card__change">Completed maintenance</p>
          </div>
        </div>
      </div>

      <div className="report-controls">
        <div className="report-tabs">
          <button 
            className={`report-tab ${selectedReport === 'overview' ? 'active' : ''}`}
            onClick={() => setSelectedReport('overview')}
          >
            Overview
          </button>
          <button 
            className={`report-tab ${selectedReport === 'shipments' ? 'active' : ''}`}
            onClick={() => setSelectedReport('shipments')}
          >
            Shipments
          </button>
          <button 
            className={`report-tab ${selectedReport === 'maintenance' ? 'active' : ''}`}
            onClick={() => setSelectedReport('maintenance')}
          >
            Maintenance
          </button>
        </div>

        <div style={{ marginTop: '1rem' }}>
          <label style={{ marginRight: '1rem', fontWeight: '600' }}>Date Range:</label>
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="form-control"
            style={{ padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }}
          >
            <option value="week">Last Week</option>
            <option value="quarter">Last Quarter</option>
            <option value="year">Last Year</option>
          </select>
        </div>
      </div>

      <div className="chart-container">
        <h3>{getReportTitle()}</h3>
        {selectedReport === 'overview' && (
          <div style={{ height: '400px' }}>
            <Bar data={spaceUtilizationData} options={chartOptions} />
          </div>
        )}
        {selectedReport === 'shipments' && (
          <div style={{ height: '400px' }}>
            <Doughnut data={shipmentStatusData} options={chartOptions} />
          </div>
        )}
        {selectedReport === 'maintenance' && (
          <div style={{ height: '400px' }}>
            <Doughnut data={maintenanceStatusData} options={chartOptions} />
          </div>
        )}
      </div>

      <div className="report-summary">
        <h3>Report Summary</h3>
        {selectedReport === 'overview' && (
          <p>
            The warehouse currently manages {totalSpaces} storage zones with a total inventory of {totalInventory.toLocaleString()} items. 
            The space utilization chart shows the current usage across all zones, helping identify areas for optimization.
          </p>
        )}
        {selectedReport === 'shipments' && (
          <p>
            Shipment performance analysis shows {deliveryRate}% delivery success rate with {totalShipments} total shipments. 
            {completedShipments} shipments have been successfully delivered, while {data.shipments.filter(s => s.status === 'Transit').length} are currently in transit.
          </p>
        )}
        {selectedReport === 'maintenance' && (
          <p>
            Maintenance performance shows {maintenanceRate}% completion rate with {totalMaintenance} total maintenance records. 
            {completedMaintenance} maintenance tasks have been completed, ensuring equipment reliability and operational efficiency.
          </p>
        )}
      </div>
    </div>
  );
}

export default Employee;
