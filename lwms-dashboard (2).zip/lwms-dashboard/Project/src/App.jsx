import React from 'react';
import Employee from './components/Employee';
import './App.css';

function App() {
  return <Employee />;
}

export default App;
