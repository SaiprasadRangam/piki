package com.example.demo.Entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class customerOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderId;

    private String customerName;
    private String productName;
    private int quantity;
    private String address;
    private String status;
    private String notification;
    private String rejectionReason;
    private String returnstatus;

    private LocalDate expectedDeliveryDate; // ✅ NEW FIELD

    public customerOrder() {}

    public customerOrder(Long orderId, String customerName, String productName, int quantity, String address,
                         String status, String notification, String rejectionReason, String returnstatus, LocalDate expectedDeliveryDate) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.productName = productName;
        this.quantity = quantity;
        this.address = address;
        this.status = status;
        this.notification = notification;
        this.rejectionReason = rejectionReason;
        this.returnstatus = returnstatus;
        this.expectedDeliveryDate = expectedDeliveryDate;
    }

    // Getters and Setters
    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getNotification() { return notification; }
    public void setNotification(String notification) { this.notification = notification; }

    public String getRejectionReason() { return rejectionReason; }
    public void setRejectionReason(String rejectionReason) { this.rejectionReason = rejectionReason; }

    public String getReturnstatus() { return returnstatus; }
    public void setReturnstatus(String returnstatus) { this.returnstatus = returnstatus; }

    public LocalDate getExpectedDeliveryDate() { return expectedDeliveryDate; }
    public void setExpectedDeliveryDate(LocalDate expectedDeliveryDate) { this.expectedDeliveryDate = expectedDeliveryDate; }
}
