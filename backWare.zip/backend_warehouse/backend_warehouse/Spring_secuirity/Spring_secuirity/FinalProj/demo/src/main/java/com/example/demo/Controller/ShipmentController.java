package com.example.demo.Controller;

import com.example.demo.Entity.Inventory;
import com.example.demo.Entity.Shipment;
import com.example.demo.Repo.InventoryRepository;
import com.example.demo.Service.ShipmentService;
import com.example.demo.ShipmentDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/shipments")
public class ShipmentController {

    private final ShipmentService service;

    public ShipmentController(ShipmentService service) {
        this.service = service;
    }

    @Autowired
    private InventoryRepository inventoryRepo;

    @PostMapping("/received")
    public ResponseEntity<String> receiveShipment(@Valid @RequestBody ShipmentDTO dto) {
        Inventory item = inventoryRepo.findById(dto.getItemId())
                .orElseThrow(() -> new IllegalArgumentException("Item ID not found in inventory"));

        Shipment shipment = new Shipment();
        shipment.setItem(item);
        shipment.setOrigin(dto.getOrigin());
        shipment.setDestination(dto.getDestination());
        shipment.setStatus(dto.getStatus());
        shipment.setExpectedDelivery(dto.getExpectedDelivery());
        shipment.setCustomerName(dto.getCustomerName());

        service.receiveShipment(shipment);
        return ResponseEntity.ok("Received Shipment");
    }


    @PutMapping("/dispatch/{id}")
    public ResponseEntity<String> dispatchShipment(@PathVariable Long id) {
        service.dispatchShipment(id);
        return ResponseEntity.ok("Dispatched");
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateShipment(@PathVariable Long id, @RequestBody ShipmentDTO dto) {
        Inventory item = inventoryRepo.findById(dto.getItemId())
                .orElseThrow(() -> new IllegalArgumentException("Item ID not found in inventory"));

        Shipment updated = service.updateShipment(id, dto, item);
        return ResponseEntity.ok("Shipment updated");
    }

    @GetMapping("/track/{id}")
    public ResponseEntity<Shipment> trackShipment(@PathVariable Long id) {
        return ResponseEntity.ok(service.trackShipment(id));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<?> getShipmentsByStatus(@PathVariable String status) {
        try {
            List<Shipment> shipments = service.getShipmentsByStatus(status);
            if (shipments.isEmpty()) {
                return ResponseEntity.status(404).body("No shipments found with status: " + status);
            }
            return ResponseEntity.ok(shipments);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Server error: " + e.getMessage());
        }
    }
    @GetMapping("/all")
    public ResponseEntity<List<Shipment>> getAllShipments() {
        return ResponseEntity.ok(service.getAllShipments());
    }
    }

