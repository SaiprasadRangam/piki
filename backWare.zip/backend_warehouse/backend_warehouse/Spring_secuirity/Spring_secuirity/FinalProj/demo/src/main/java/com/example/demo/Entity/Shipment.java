package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name = "Shipments")
public class Shipment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long shipmentId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "item_id")
    @JsonManagedReference
//    @JoinColumn(name = "item_id", nullable = false)
//    @NotNull(message = "Item is required")
    private Inventory item;

    @NotBlank(message = "Origin is required")
    private String origin;

    @NotBlank(message = "Destination is required")
    private String destination;

    @NotBlank(message = "Status is required")
    private String status;

    @NotNull(message = "Expected delivery date is required")
    private LocalDate expectedDelivery;

    @NotBlank(message = "Customer name is required")
    private String customerName;


    public Shipment() {}

    public Shipment(Long shipmentId, Inventory item, String origin, String destination, String status, LocalDate expectedDelivery, String customerName) {
        this.shipmentId = shipmentId;
        this.item = item;
        this.origin = origin;
        this.destination = destination;
        this.status = status;
        this.expectedDelivery = expectedDelivery;
        this.customerName = customerName;
    }

    // Getters and setters
    public Long getShipmentId() { return shipmentId; }
    public void setShipmentId(Long shipmentId) { this.shipmentId = shipmentId; }

    public Inventory getItem() { return item; }
    public void setItem(Inventory item) { this.item = item; }

    public String getOrigin() { return origin; }
    public void setOrigin(String origin) { this.origin = origin; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDate getExpectedDelivery() { return expectedDelivery; }
    public void setExpectedDelivery(LocalDate expectedDelivery) { this.expectedDelivery = expectedDelivery; }

    public @NotBlank(message = "Customer name is required") String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(@NotBlank(message = "Customer name is required") String customerName) {
        this.customerName = customerName;
    }
}
