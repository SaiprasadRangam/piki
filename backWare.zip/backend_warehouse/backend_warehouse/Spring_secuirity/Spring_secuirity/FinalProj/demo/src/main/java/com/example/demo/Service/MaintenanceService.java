package com.example.demo.Service;
import com.example.demo.Repo.MaintenanceRepo;
import com.example.demo.Entity.MaintenanceSchedule;
import com.example.demo.ExceptionHandler.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MaintenanceService  {

    private final MaintenanceRepo repository;

    public MaintenanceService(MaintenanceRepo repository) {

        this.repository = repository;
    }


    public MaintenanceSchedule scheduleMaintenance(MaintenanceSchedule schedule) {

        return repository.save(schedule);
    }


    public MaintenanceSchedule updateSchedule(Long id, MaintenanceSchedule schedule) {
        MaintenanceSchedule existing = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Maintenance schedule not found with id: " + id));

        existing.setEquipmentId(schedule.getEquipmentId());
        existing.setTaskDescription(schedule.getTaskDescription());
        existing.setScheduledDate(schedule.getScheduledDate());
        existing.setCompletionStatus(schedule.getCompletionStatus());

        return repository.save(existing);
    }


    public List<MaintenanceSchedule> viewSchedule() {

        return repository.findAll();
    }
}
