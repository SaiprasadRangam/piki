package com.example.demo.Service;

import com.example.demo.Entity.Inventory;
import com.example.demo.ExceptionHandler.ResourceNotFoundException;
import com.example.demo.Entity.Shipment;
import com.example.demo.Repo.ShipmentRepo;
import com.example.demo.ShipmentDTO;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ShipmentService {

    private final ShipmentRepo repository;

    public ShipmentService(ShipmentRepo repository) {
        this.repository = repository;
    }

    public Shipment receiveShipment(Shipment shipment) {
        // Optional: validate or transform data here
        return repository.save(shipment);
    }

    public Shipment dispatchShipment(Long id) {
        Shipment existing = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shipment not found with id: " + id));
        existing.setStatus("DISPATCHED");
        return repository.save(existing);
    }

    public Shipment trackShipment(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shipment not found with id: " + id));
    }

    public List<Shipment> getShipmentsByStatus(String status) {
        return repository.findByStatusIgnoreCase(status);
    }
    public List<Shipment> getAllShipments() {
        return repository.findAll();
    }
    public Shipment updateShipment(Long id, ShipmentDTO dto, Inventory item) {
        Shipment existing = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shipment not found with id: " + id));

        existing.setItem(item);
        existing.setOrigin(dto.getOrigin());
        existing.setDestination(dto.getDestination());
        existing.setStatus(dto.getStatus());
        existing.setExpectedDelivery(dto.getExpectedDelivery());
        existing.setCustomerName(dto.getCustomerName());


        return repository.save(existing);
    }


}
