package com.example.demo.Entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name = "Maintenance")
public class MaintenanceSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long scheduleId;

    @NotNull(message = "Equipment ID is required")
    private Long equipmentId;

    @NotBlank(message = "Task description is required")
    @Column(length = 500)
    private String taskDescription;

    @NotNull(message = "Scheduled date is required")
    private LocalDate scheduledDate;

    @NotBlank(message = "Completion status is required")
    private String completionStatus;

    public MaintenanceSchedule(Long scheduleId, Long equipmentId, String taskDescription, LocalDate scheduledDate, String completionStatus) {
        this.scheduleId = scheduleId;
        this.equipmentId = equipmentId;
        this.taskDescription = taskDescription;
        this.scheduledDate = scheduledDate;
        this.completionStatus = completionStatus;
    }

    public MaintenanceSchedule() {
    }

    public Long getScheduleId() {

        return scheduleId;
    }

    public void setScheduleId(Long scheduleId) {

        this.scheduleId = scheduleId;
    }

    public Long getEquipmentId() {

        return equipmentId;
    }

    public void setEquipmentId(Long equipmentId) {

        this.equipmentId = equipmentId;
    }

    public String getTaskDescription() {

        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {

        this.taskDescription = taskDescription;
    }

    public LocalDate getScheduledDate() {

        return scheduledDate;
    }

    public void setScheduledDate(LocalDate scheduledDate) {

        this.scheduledDate = scheduledDate;
    }

    public String getCompletionStatus() {

        return completionStatus;
    }

    public void setCompletionStatus(String completionStatus) {

        this.completionStatus = completionStatus;
    }
}