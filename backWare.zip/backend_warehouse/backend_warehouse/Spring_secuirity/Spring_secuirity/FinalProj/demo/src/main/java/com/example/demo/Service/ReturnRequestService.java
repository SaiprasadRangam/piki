package com.example.demo.Service;

import com.example.demo.Entity.customerOrder;
import com.example.demo.Entity.ReturnRequest;
import com.example.demo.Repo.OrderRepository;
import com.example.demo.Repo.ReturnRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReturnRequestService {
    @Autowired
    private ReturnRequestRepository returnRepo;

    @Autowired
    private OrderRepository orderRepo;

    public String submitRequest(ReturnRequest request) {
        customerOrder order = orderRepo.findById(request.getOrderId()).orElse(null);
        if (order == null) return "Order not found";

        if (!order.getCustomerName().equalsIgnoreCase(request.getCustomerName()) ||
                !order.getProductName().equalsIgnoreCase(request.getProductName()) ||
                request.getQuantityRequested() > order.getQuantity()) {
            return "Invalid return request";
        }

        request.setStatus(ReturnRequest.Status.PENDING);
        returnRepo.save(request);
        return "Return request submitted";
    }

    public List<ReturnRequest> getRequestsByCustomer(String customerName) {
        return returnRepo.findByCustomerName(customerName);
    }

    public ReturnRequest acceptRequest(Long id, String expectedDate) {
        ReturnRequest request = returnRepo.findById(id).orElseThrow();
        request.setStatus(ReturnRequest.Status.ACCEPTED);
        request.setExpectedDeliveryDate(expectedDate);
        returnRepo.save(request);
        return request;
    }

    public ReturnRequest rejectRequest(Long id, String reason) {
        ReturnRequest request = returnRepo.findById(id).orElseThrow();
        request.setStatus(ReturnRequest.Status.REJECTED);
        request.setRejectionReason(reason);
        returnRepo.save(request);
        return request;
    }

    public List<ReturnRequest> getAllRequests() {
        return returnRepo.findAll();
    }
}

