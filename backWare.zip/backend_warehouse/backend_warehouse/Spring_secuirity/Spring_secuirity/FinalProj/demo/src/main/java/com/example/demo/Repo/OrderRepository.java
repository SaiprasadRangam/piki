package com.example.demo.Repo;

import com.example.demo.Entity.customerOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface OrderRepository extends JpaRepository<customerOrder, Long> {

    List<customerOrder> findByCustomerNameIgnoreCase(String username);

    @Query("SELECT o FROM customerOrder o WHERE LOWER(o.customerName) = LOWER(:name) AND (o.returnstatus = 'RETURN_APPROVED' OR o.returnstatus = 'RETURN_REJECTED')")
    List<customerOrder> findReturnItemsByCustomerName(@Param("name") String name);
}
