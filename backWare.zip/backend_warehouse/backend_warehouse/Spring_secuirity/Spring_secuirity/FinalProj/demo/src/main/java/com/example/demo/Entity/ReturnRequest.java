package com.example.demo.Entity;

import jakarta.persistence.*;

@Entity
public class ReturnRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long orderId;
    private String customerName;
    private String productName;
    private int quantityRequested;

    @Enumerated(EnumType.STRING)
    private Status status = Status.PENDING;

    private String expectedDeliveryDate;
    private String rejectionReason;

    public enum Status {
        PENDING, ACCEPTED, REJECTED
    }
public ReturnRequest() {

}
    public ReturnRequest(Long id, Long orderId, String customerName, String productName, int quantityRequested, Status status, String expectedDeliveryDate, String rejectionReason) {
        this.id = id;
        this.orderId = orderId;
        this.customerName = customerName;
        this.productName = productName;
        this.quantityRequested = quantityRequested;
        this.status = status;
        this.expectedDeliveryDate = expectedDeliveryDate;
        this.rejectionReason = rejectionReason;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantityRequested() {
        return quantityRequested;
    }

    public void setQuantityRequested(int quantityRequested) {
        this.quantityRequested = quantityRequested;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getExpectedDeliveryDate() {
        return expectedDeliveryDate;
    }

    public void setExpectedDeliveryDate(String expectedDeliveryDate) {
        this.expectedDeliveryDate = expectedDeliveryDate;
    }

    public String getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(String rejectionReason) {
        this.rejectionReason = rejectionReason;
    }
}

