package com.example.demo.Service;

import com.example.demo.Entity.customerOrder;
import com.example.demo.Repo.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public customerOrder placeOrder(customerOrder order) {
        return orderRepository.save(order);
    }

    @Override
    public List<customerOrder> getOrdersByCustomerName(String name) {
        return orderRepository.findByCustomerNameIgnoreCase(name);
    }

    @Override
    public String updateOrderStatus(Long orderId, String status, String reason) {
        Optional<customerOrder> orderOpt = orderRepository.findById(orderId);
        if (orderOpt.isPresent()) {
            customerOrder order = orderOpt.get();
            order.setStatus(status);
            orderRepository.save(order);
            return "Order status updated to " + status;
        } else {
            return "Order not found.";
        }
    }

    @Override
    public List<customerOrder> getAllOrders() {
        return orderRepository.findAll();
    }

    @Override
    public boolean markOrdersAsReturnedByUsername(String username) {
        List<customerOrder> orders = orderRepository.findByCustomerNameIgnoreCase(username);
        boolean updated = false;

        for (customerOrder order : orders) {
            String status = order.getStatus() != null ? order.getStatus().toUpperCase() : "";
            if (status.equals("ORDERED") || status.equals("DELIVERED") || status.equals("APPROVED")) {
                order.setReturnstatus("RETURN_REQUESTED");
                orderRepository.save(order);
                updated = true;
            }
        }

        return updated;
    }

    @Override
    public boolean updateReturnStatus(Long orderId, String returnstatus, String rejectionReason, LocalDate expectedDeliveryDate) {
        Optional<customerOrder> orderOpt = orderRepository.findById(orderId);
        if (orderOpt.isPresent()) {
            customerOrder order = orderOpt.get();
            order.setReturnstatus(returnstatus);
            order.setRejectionReason(rejectionReason);
            order.setExpectedDeliveryDate(expectedDeliveryDate);
            orderRepository.save(order);
            return true;
        }
        return false;
    }

    @Override
    public customerOrder getLatestOrderForCustomer(String username) {
        List<customerOrder> orders = getOrdersByCustomerName(username);
        if (orders.isEmpty()) return null;

        orders.sort((o1, o2) -> Long.compare(o2.getOrderId(), o1.getOrderId()));
        return orders.get(0);
    }

    @Override
    public List<customerOrder> getReturnItemsByCustomerName(String name) {
        return orderRepository.findReturnItemsByCustomerName(name);
    }
}
