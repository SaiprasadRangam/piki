package com.example.demo.Controller;

import com.example.demo.Entity.customerOrder;
import com.example.demo.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/orders")
@CrossOrigin(origins = "http://localhost:5173")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/place")
    public ResponseEntity<customerOrder> placeOrder(@RequestBody customerOrder order) {
        try {
            customerOrder savedOrder = orderService.placeOrder(order);
            return ResponseEntity.ok(savedOrder);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(null);
        }
    }

    @GetMapping("/my-orders/{name}")
    public ResponseEntity<List<customerOrder>> getOrdersForCustomer(@PathVariable String name) {
        try {
            List<customerOrder> orders = orderService.getOrdersByCustomerName(name);
            return ResponseEntity.ok(orders);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(null);
        }
    }

    @PutMapping("/updateStatus/{orderId}")
    public ResponseEntity<String> updateStatus(@PathVariable Long orderId, @RequestBody Map<String, String> payload) {
        try {
            String status = payload.get("status");
            String result = orderService.updateOrderStatus(orderId, status, "");
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Failed to update status.");
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<customerOrder>> getAllOrders() {
        try {
            return ResponseEntity.ok(orderService.getAllOrders());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(null);
        }
    }

    @PostMapping("/return-by-username/{username}")
    public ResponseEntity<String> returnOrdersByUsername(@PathVariable String username) {
        try {
            boolean success = orderService.markOrdersAsReturnedByUsername(username);
            if (success) {
                return ResponseEntity.ok("Return request(s) submitted successfully.");
            } else {
                return ResponseEntity.status(404).body("No eligible orders found for return.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error processing return request.");
        }
    }

    @PutMapping("/updateReturnStatus/{orderId}")
    public ResponseEntity<String> updateReturnStatus(@PathVariable Long orderId, @RequestBody Map<String, String> payload) {
        try {
            String returnstatus = payload.get("returnstatus");
            String rejectionReason = payload.get("rejectionReason");
            String expectedDateStr = payload.get("expectedDeliveryDate");

            LocalDate expectedDate = null;
            if (expectedDateStr != null && !expectedDateStr.isEmpty()) {
                expectedDate = LocalDate.parse(expectedDateStr);
            }

            boolean updated = orderService.updateReturnStatus(orderId, returnstatus, rejectionReason, expectedDate);
            if (updated) {
                return ResponseEntity.ok("Return status updated successfully.");
            } else {
                return ResponseEntity.status(404).body("Order not found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error updating return status.");
        }
    }

    @GetMapping("/latest/{username}")
    public ResponseEntity<customerOrder> getLatestOrder(@PathVariable String username) {
        try {
            customerOrder latestOrder = orderService.getLatestOrderForCustomer(username);
            if (latestOrder != null) {
                return ResponseEntity.ok(latestOrder);
            } else {
                return ResponseEntity.status(404).body(null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(null);
        }
    }

    @GetMapping("/return-items/{name}")
    public ResponseEntity<List<customerOrder>> getReturnItemsForCustomer(@PathVariable String name) {
        try {
            List<customerOrder> returnOrders = orderService.getReturnItemsByCustomerName(name);
            return ResponseEntity.ok(returnOrders);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(null);
        }
    }
}
