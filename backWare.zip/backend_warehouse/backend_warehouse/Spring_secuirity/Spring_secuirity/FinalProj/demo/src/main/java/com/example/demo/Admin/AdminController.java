package com.example.demo.Admin;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AdminController {

        private static final String VALID_USERNAME = "admin";
        private static final String VALID_PASSWORD = "password123";

        @PostMapping("/login")
        public String login(@RequestBody AdminLoginRequest request) {
            if (VALID_USERNAME.equals(request.getUsername()) &&
                    VALID_PASSWORD.equals(request.getPassword())) {
                return "success";
            } else {
                return "Invalid credentials";
            }
        }
    @GetMapping("/info")
    public String info() {
        return "Use POST /auth/login with username and password to authenticate.";
    }
}
