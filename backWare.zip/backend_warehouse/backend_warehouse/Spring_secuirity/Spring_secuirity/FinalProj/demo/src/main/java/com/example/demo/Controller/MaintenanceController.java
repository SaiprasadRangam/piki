package com.example.demo.Controller;
import com.example.demo.Entity.MaintenanceSchedule;
import com.example.demo.Service.MaintenanceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/maintenance")
public class MaintenanceController {

    private final MaintenanceService service;

    public MaintenanceController(MaintenanceService service) {

        this.service = service;
    }

    @PostMapping("/schedule")
    public ResponseEntity<String> scheduleMaintenance(
            @Valid @RequestBody MaintenanceSchedule schedule) {
        service.scheduleMaintenance(schedule);
        return ResponseEntity.ok("Scheduled");
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateSchedule(
            @PathVariable Long id, @Valid @RequestBody MaintenanceSchedule schedule) {
        service.updateSchedule(id, schedule);
        return ResponseEntity.ok("Updated");
    }

    @GetMapping("/viewMaintenance")
    public ResponseEntity<List<MaintenanceSchedule> >viewSchedule() {
        return ResponseEntity.ok(service.viewSchedule());
    }
}
