package com.example.demo.Controller;

import com.example.demo.Entity.ReturnRequest;
import com.example.demo.Service.ReturnRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/returns")
@CrossOrigin(origins = "*")
public class ReturnRequestController {
    @Autowired
    private ReturnRequestService service;

    @PostMapping("/request")
    public ResponseEntity<String> submitRequest(@RequestBody ReturnRequest request) {
        String result = service.submitRequest(request);
        return result.equals("Return request submitted") ?
                ResponseEntity.ok(result) : ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/status/{customerName}")
    public List<ReturnRequest> getCustomerRequests(@PathVariable String customerName) {
        return service.getRequestsByCustomer(customerName);
    }

    @PostMapping("/accept/{id}")
    public ReturnRequest acceptRequest(@PathVariable Long id, @RequestParam String expectedDate) {
        return service.acceptRequest(id, expectedDate);
    }

    @PostMapping("/reject/{id}")
    public ReturnRequest rejectRequest(@PathVariable Long id, @RequestParam String reason) {
        return service.rejectRequest(id, reason);
    }

    @GetMapping("/all")
    public List<ReturnRequest> getAllRequests() {
        return service.getAllRequests();
    }
}
