package com.example.demo.Service;

import com.example.demo.Entity.Space;
import com.example.demo.Repo.SpaceRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SpaceServices {

    private final SpaceRepository spaceRepository;

    public SpaceServices(SpaceRepository spaceRepository) {
        this.spaceRepository = spaceRepository;
    }

    // GET /space/view
    public List<Space> viewSpaceUsage() {
        return spaceRepository.findAll();
    }

    // POST /space/create
    public Space createSpace(Space space) {
        // Ensure availableCapacity is correctly calculated before saving
        double available = space.getTotalCapacity() - space.getUsedCapacity();
        space.setAvailableCapacity(available);
        return spaceRepository.save(space);
    }

    // POST /space/allocate/{id}?volume=...
    public Space allocateSpace(Long id, Double volume) {
        Space space = spaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Space not found with ID: " + id));

        double newUsed = space.getUsedCapacity() + volume;
        if (newUsed > space.getTotalCapacity()) {
            throw new RuntimeException("Allocation exceeds total capacity");
        }

        space.setUsedCapacity(newUsed);
        space.setAvailableCapacity(space.getTotalCapacity() - newUsed);
        return spaceRepository.save(space);
    }

    // POST /space/free/{id}?volume=...
    public Space freeSpace(Long id, Double volume) {
        Space space = spaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Space not found with ID: " + id));

        double newUsed = space.getUsedCapacity() - volume;
        if (newUsed < 0) {
            newUsed = 0;
        }

        space.setUsedCapacity(newUsed);
        space.setAvailableCapacity(space.getTotalCapacity() - newUsed);
        return spaceRepository.save(space);
    }
}
