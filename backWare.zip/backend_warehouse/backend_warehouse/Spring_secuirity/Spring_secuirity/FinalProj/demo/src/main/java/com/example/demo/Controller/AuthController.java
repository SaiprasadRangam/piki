package com.example.demo.Controller;


import com.example.demo.Entity.LwmsUser;
import com.example.demo.Service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:5173") // Allow frontend access
@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthenticationConfiguration config;
    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    public AuthController(AuthenticationConfiguration config,
                          UserService userService,
                          PasswordEncoder passwordEncoder) {
        this.config = config;
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/register")
    public String register(@RequestBody LwmsUser user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userService.registerUser(user);
        return "Registration successful";
    }
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Map<String, String> body,
                                        HttpSession session, Principal principal) {
        String username = body.get("username");
        String password = body.get("password");
//        System.out.println("user: " + username);
//        System.out.println("user: " + password);
        try {
            Authentication auth = config.getAuthenticationManager().authenticate(
                    new UsernamePasswordAuthenticationToken(username, password)
            );

            session.setAttribute("username", auth.getName());
            return ResponseEntity.ok("Login successful for user: " + auth.getName());

        } catch (BadCredentialsException ex) {

            return ResponseEntity.status(401).body("Invalid username or password");
        } catch (AuthenticationException ex) {

            return ResponseEntity.status(401).body("Authentication failed: " + ex.getMessage());
        } catch (Exception ex) {
            // Fallback for other unexpected exceptions
            return ResponseEntity.status(500).body("An unexpected error occurred");
        }
    }

}
