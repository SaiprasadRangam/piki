package com.example.demo.Service;

import com.example.demo.Entity.customerOrder;

import java.time.LocalDate;
import java.util.List;

public interface OrderService {

    customerOrder placeOrder(customerOrder order);

    List<customerOrder> getOrdersByCustomerName(String name);

    String updateOrderStatus(Long orderId, String status, String reason);

    List<customerOrder> getAllOrders();

    boolean markOrdersAsReturnedByUsername(String username);

    boolean updateReturnStatus(Long orderId, String returnstatus, String rejectionReason, LocalDate expectedDeliveryDate);

    customerOrder getLatestOrderForCustomer(String username);

    List<customerOrder> getReturnItemsByCustomerName(String name); // ✅ NEW
}
