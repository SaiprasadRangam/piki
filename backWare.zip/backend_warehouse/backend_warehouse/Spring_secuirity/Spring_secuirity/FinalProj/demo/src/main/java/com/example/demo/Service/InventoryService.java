package com.example.demo.Service;

import com.example.demo.Entity.Inventory;
import com.example.demo.Repo.InventoryRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service

public class InventoryService {
    private final InventoryRepository repository;

    public InventoryService(InventoryRepository repository) {
        this.repository = repository;
    }

    public void addItem(Inventory inventory) {
        inventory.setLastUpdated(LocalDateTime.now());
        repository.save(inventory);
    }

    public void updateItem(Long id, Inventory updated) {
        Inventory existing = repository.findById(id).orElseThrow();
        existing.setItemName(updated.getItemName());
        existing.setCategory(updated.getCategory());
        existing.setQuantity(updated.getQuantity());
        existing.setLocation(updated.getLocation());
        existing.setLastUpdated(LocalDateTime.now());
        repository.save(existing);
    }

    public void removeItem(Long id) {
        repository.deleteById(id);
    }

    public List<Inventory> viewInventory() {
        return repository.findAll();
    }
}
